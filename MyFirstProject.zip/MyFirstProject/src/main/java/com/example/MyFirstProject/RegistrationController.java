package com.example.MyFirstProject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller

public class RegistrationController {
	@RequestMapping("/regform")
	public String register() {
		return "registration";
	}
	@RequestMapping("/userDetail")
	public String userInfo(UserRegistration reg) {
		System.out.println("i am detail....."+reg.getUName());
		return "userdetails";
	}
}
